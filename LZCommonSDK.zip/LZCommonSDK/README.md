# LZCommonSDK

[![CI Status](https://img.shields.io/travis/zhenglinmao/LZCommonSDK.svg?style=flat)](https://travis-ci.org/zhenglinmao/LZCommonSDK)
[![Version](https://img.shields.io/cocoapods/v/LZCommonSDK.svg?style=flat)](https://cocoapods.org/pods/LZCommonSDK)
[![License](https://img.shields.io/cocoapods/l/LZCommonSDK.svg?style=flat)](https://cocoapods.org/pods/LZCommonSDK)
[![Platform](https://img.shields.io/cocoapods/p/LZCommonSDK.svg?style=flat)](https://cocoapods.org/pods/LZCommonSDK)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

LZCommonSDK is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'LZCommonSDK'
```

## Author

zhenglinmao, hanbocci@163.com

## License

LZCommonSDK is available under the MIT license. See the LICENSE file for more info.
